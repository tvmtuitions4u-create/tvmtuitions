# ICSE Class 10 Robotics & AI - Solved 2026 Question Paper
# Source: KnowledgeBoat
# Images included in this folder

## SECTION A

### Question 1(i)
Study the image given below.  
In which field is this robot used?  
(a) Defence (b) Agriculture (c) Medicine (d) Entertainment  

**Answer:** Agriculture  
**Reason:** The figure shows a robot used in agricultural fields. Such robots are designed to perform tasks like planting seeds, harvesting crops, spraying fertilizers or pesticides, and monitoring crop health.  
**Image:** robot_agri.png

### Question 1(ii)
............... is an example of deterministic computing.  
(a) Traffic light sequencing (b) Autonomous driving (c) Stock market prediction (d) Face recognition  

**Answer:** Traffic light sequencing  
**Reason:** In traffic light sequencing, the signals change in a fixed order based on predefined time intervals. For a given input, the output is always the same and predictable.

### Question 1(iii)
A room heater is an example of a/an:  
(a) gear (b) robot (c) actuator (d) machine  

**Answer:** machine  
**Reason:** A room heater is a machine because it uses electrical energy to do useful work by producing heat energy.

### Question 1(iv)
Tinkercad is commonly used for:  
(a) simulating robotic movements. (b) data encryption. (c) performing gear ratio calculations only. (d) building operating systems.  

**Answer:** simulating robotic movements.  
**Reason:** Tinkercad is a simulation tool used to design and visualize circuits and robotic systems.

### Question 1(v)
In the block diagram of a robotic control system, the correct sequence is:  
(a) Input → Robot → Controller → Feedback  
(b) Feedback → Input → Controller → Robot  
(c) Input → Controller → Robot → Feedback  
(d) Controller → Input → Robot → Feedback  

**Answer:** Input → Controller → Robot → Feedback  
**Reason:** Input is given to the controller, which sends commands to the robot. Feedback monitors and adjusts the system.

### Question 1(vi)
Which of the following is an example of a linear actuator?  
(a) DC motor (b) Pneumatic piston (c) Arduino (d) Electric fan  

**Answer:** Pneumatic piston  
**Reason:** A linear actuator produces motion in a straight line. A pneumatic piston moves back and forth using compressed air.

### Question 1(vii)
From the following, which function of Python checks whether all characters in a string 's' are alphanumeric?  
(a) s.allnum() (b) s.isnumal() (c) s.isalnum() (d) s.isalphanum()  

**Answer:** s.isalnum()  
**Reason:** isalnum() checks if all characters are letters or digits.

### Question 1(viii)
A motor drives a small gear with 10 teeth connected to a larger gear with 40 teeth. What is the gear ratio?  
(a) 4 : 1 (b) 1 : 4 (c) 1 : 2 (d) 2 : 1  

**Answer:** 4 : 1  
**Reason:** Gear Ratio = teeth on driven / teeth on driving = 40/10 = 4.

### Question 1(ix)
Which string operator in Python finds the length of string 'a'?  
(a) len(a) (b) len() (c) a.len() (d) a.len(a)  

**Answer:** len(a)

### Question 1(x)
Unauthorised hardware access leads to:  
(a) loss of data. (b) increased computer speed. (c) better performance. (d) having more data.  

**Answer:** loss of data.

### Question 1(xi)
In machine learning, testing data is primarily used to:  
(a) train the model for better performance.  
(b) measure model performance on unseen data.  
(c) store training parameters.  
(d) provide labels for training.  

**Answer:** measure model performance on unseen data.

### Question 1(xii)
The function of a sensor is to:  
(a) detect changes in environment and send signals.  
(b) process the input data and make decisions.  
(c) change electrical energy into motion.  
(d) supply power to the robot.  

**Answer:** detect changes in environment and send signals.

### Question 1(xiii)
The purpose of Turing Test is to evaluate:  
(a) memory consumption of a computer.  
(b) the processing speed of computers and humans.  
(c) two computer programs.  
(d) if a machine can exhibit human-like responses.  

**Answer:** if a machine can exhibit human-like responses.

### Question 1(xiv)
............... software is used to simulate a robotic system.  
(a) LibreOffice (b) MS Word (c) Tinkercad (d) MySQL  

**Answer:** Tinkercad

### Question 1(xv)
Assertion (A): Robots use actuators for movement.  
Reason (R): Actuators sense the environment and convert it to electrical signals.  

(a) (A) true, (R) false  
(b) (A) false, (R) true  
(c) Both true, R explains A  
(d) Both true, R does not explain A  

**Answer:** (A) is true but (R) is false.  
**Reason:** Actuators produce movement. Sensing is done by sensors.

### Question 1(xvi)
Identify the type of graph shown below:  
(a) Scatter plot (b) Bar graph (c) Pie chart (d) Line graph  

**Answer:** Line graph  
**Image:** line_graph.png

### Question 1(xvii)
In AI problem scoping, "Who" refers to the:  
(a) dataset used for training.  
(b) end users affected by the project.  
(c) programming environment used.  
(d) hardware requirements of the project.  

**Answer:** end users affected by the project.

### Question 1(xviii)
Give the output of the following Python code:  
msg = "Artificial Intelligence"  
print(msg[11:14])  

Options: tel / Int / ell / gen  

**Answer:** Int  
**Reason:** Indices 11,12,13 = I,n,t

### Question 1(xix)
The keyword used to include a package or module in a Python program is:  
(a) export (b) include (c) collect (d) import  

**Answer:** import

### Question 1(xx)
What will be the output of the Python code given below?  
x = "BOARD EXAMINATION"  
print(x[0:4:2])  

Options: BOAR / BA / OR / Error  

**Answer:** BA  
**Reason:** Indices 0 and 2 = B and A

## SECTION B (Selected longer answers)

### Question 2(i)
Mention any two sensors used in autonomous drones.  
**Answer:** GPS sensor, Ultrasonic sensor

### Question 2(ii)
'In a hospital, cobots assist nurses in delivering medicines to patients.'  
Give any two advantages of using cobots in hospitals.  
**Answer:** Reduce workload of nurses; Improve efficiency and accuracy of delivery.

### Question 2(iii)
What is spur gear? Mention one application of spur gear in robotics.  
**Answer:** Spur gear has straight teeth parallel to the shaft axis, transmits motion between parallel shafts. Application: robotic arms for joint movement.

### Question 2(iv)
Explain the role of data in Machine Learning.  
**Answer:** Data is raw facts used to train models to identify patterns. Quality and quantity affect model accuracy.

### Question 3(iii)
Write a Python program using Matplotlib to plot a bar chart for monthly sales.  
**Image:** bar_chart.png

### Question 4(iii)
Write a Python program to plot a pie chart for student marks.  
**Image:** pie_chart.png

### Question 5(i)
Name the type of sensor for:  
(a) Detecting obstacles → Ultrasonic sensor  
(b) Measuring light intensity → Light sensor  
(c) Measuring temperature → Temperature sensor

### Question 6(i)
Briefly describe the different types of joints in robotics.  
**Answer:** Prismatic (linear/sliding), Revolute (rotational/hinge), Spherical (ball-and-socket).

### Question 7(ii)
Briefly explain supervised learning.  
**Answer:** Model trained on labelled data (inputs + known outputs). Uses training and test sets to learn and evaluate.

---
**Images in this folder:**
- robot_agri.png (Q1(i))
- line_graph.png (Q1(xvi))
- bar_chart.png (Q3(iii))
- pie_chart.png (Q4(iii))
